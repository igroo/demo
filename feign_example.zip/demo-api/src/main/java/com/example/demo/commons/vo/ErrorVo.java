package com.example.demo.commons.vo;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ErrorVo {
	private String code;
	private String message;

	public ErrorVo() {
		this.code = "00";
		this.message = "";
	}
}
