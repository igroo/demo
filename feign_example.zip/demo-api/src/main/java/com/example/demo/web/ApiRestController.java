package com.example.demo.web;

import java.util.HashMap;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.commons.vo.ErrorVo;
import com.example.demo.vo.GroupVo;
import com.example.demo.vo.UserGroupVo;
import com.example.demo.vo.UserVo;

@RestController
@RequestMapping("/api")
public class ApiRestController {

	@GetMapping
	public ResponseEntity<?> get() {
		UserGroupVo userGroupVo = new UserGroupVo();
		userGroupVo.setUserVo(new UserVo("test id", "test name"));
		userGroupVo.setGroupVo(new GroupVo("00001", "Test Group"));

		return new ResponseEntity<UserGroupVo>(userGroupVo, HttpStatus.OK);
	}

	@GetMapping("/error")
	public ResponseEntity<?> getError() {
		HttpHeaders headers = new HttpHeaders();
	    headers.add("Content-Type", MediaType.APPLICATION_JSON_UTF8_VALUE);

//		return new ResponseEntity<UserGroupVo>(userGroupVo, HttpStatus.OK);

	    HashMap error = new HashMap();
	    error.put("error", new ErrorVo("ERROR", "ERROR MESSAGE"));

		return new ResponseEntity<Object>(error, headers, HttpStatus.OK);
	}
}
