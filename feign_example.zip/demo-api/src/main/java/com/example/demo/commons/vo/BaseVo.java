package com.example.demo.commons.vo;

import lombok.Data;

@Data
public class BaseVo {
	private ErrorVo errorVo = new ErrorVo();
}
