package com.example.demo.vo;

import com.example.demo.commons.vo.BaseVo;
import com.example.demo.commons.vo.ErrorVo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserGroupVo extends BaseVo {
//	private ErrorVo errorVo;
	private GroupVo groupVo;
	private UserVo userVo;
}
