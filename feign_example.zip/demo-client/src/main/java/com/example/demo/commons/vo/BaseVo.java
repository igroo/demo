package com.example.demo.commons.vo;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class BaseVo {
	@JsonProperty("error")
	private ErrorVo errorVo;
}
