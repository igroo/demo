package com.example.demo.commons.vo;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ErrorVo {

	@JsonProperty("code")
	private String code;

	@JsonProperty("message")
	private String message;

	public ErrorVo() {
		this.code = "00";
		this.message = "";
	}
}
