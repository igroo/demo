package com.example.demo.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;

import com.example.demo.commons.vo.ErrorVo;
import com.example.demo.vo.UserGroupVo;

@FeignClient(name = "api-client", url = "http://localhost:8080/api")
public interface ApiClient {
	@GetMapping
	public ResponseEntity<UserGroupVo> get();

	@GetMapping("/error")
	public ResponseEntity<UserGroupVo> getError();
}
