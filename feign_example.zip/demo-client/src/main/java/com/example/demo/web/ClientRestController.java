package com.example.demo.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.client.ApiClient;
import com.example.demo.commons.vo.ErrorVo;
import com.example.demo.vo.UserGroupVo;

@RestController
@RequestMapping("/client")
public class ClientRestController {

	@Autowired
	private ApiClient apiClient;

	@GetMapping
	public ResponseEntity<UserGroupVo> get() {
		return apiClient.get();
	}

	@GetMapping("/error")
	public ResponseEntity<UserGroupVo> getError() {
		return apiClient.getError();
	}
}
